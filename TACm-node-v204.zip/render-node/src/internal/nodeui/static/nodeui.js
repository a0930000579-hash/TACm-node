/* TACm Chain — Node Console (M86) */
"use strict";
(function () {
  var dict = {
    zh: {
      "n.brandSub": "節點控制台",
      "n.synced": "已同步",
      "n.syncing": "同步中",
      "n.behind": "落後 {n} 塊",
      "n.openMainnet": "開啟主網",
      "n.deployerBtn": "架設者面板",
      "n.heroDeployer": "開啟架設者面板",
      "n.heroJoin": "如何加入",
      "n.capTitle": "網路能力",
      "n.capGov": "參數化治理",
      "n.capDeFi": "DeFi 借貸",
      "n.capAlert": "Webhook 警報",
      "n.capBridge": "橋 Kill-switch",
      "n.heroEyebrow": "TACm 智能鏈 · 主網",
      "n.heroTitle": "節點<br>控制台",
      "n.heroDesc": "運行 TAC 節點、守護網路、驗證區塊並獲得 45% 節點獎勵（在線均分）——全部在專屬的節點品牌面板完成。",
      "n.cTip": "鏈頂高度",
      "n.cTipSub": "最新區塊高度",
      "n.cFinal": "最終化",
      "n.cFinalSub": "BFT 最終化高度",
      "n.cDiff": "動態難度",
      "n.cDiffSub": "動態 PoT 難度",
      "n.cSync": "同步進度",
      "n.cSyncSub": "落後最佳節點塊數",
      "n.pNode": "節點身分",
      "n.kAddress": "節點地址",
      "n.kNodeId": "節點 ID",
      "n.kIdentity": "身分金鑰",
      "n.kUptime": "運行時間",
      "n.kBaseFee": "基礎費",
      "n.kConsensus": "共識機制",
      "n.kReward": "節點獎勵",
      "n.rewardDesc": "每個區塊按發行模型（年衰減/annual_decay）鑄造：45% 歸在線 PoT 節點均分、15% 挹注獎勵池、40% 依在線算力分配給礦工。",
      "n.pPeers": "P2P 節點",
      "n.tNode": "節點",
      "n.tHeight": "高度",
      "n.tFinal": "最終化",
      "n.tState": "狀態",
      "n.tCipher": "加密",
      "n.plain": "明文",
      "n.cipherOn": "加密",
      "n.pValidators": "節點",
      "n.tAddress": "地址",
      "n.tPower": "權重",
      "n.pBlocks": "最新區塊",
      "n.tProposer": "出塊者",
      "n.tTx": "交易數",
      "n.tDiff": "難度",
      "n.pJoin": "運行你自己的節點",
      "n.oneClick": "一鍵安裝（三平台通用）", "n.oneClickTip": "自動偵測 systemd / nohup / Render、安裝 Go、編譯、啟動並輸出控制台網址。", "n.rawTip": "推送後節點二進位即獲得永久 raw 直鏈，不再受短鏈時效影響。",
      "n.github": "原始碼永久固化（GitHub）",
      "n.renderUpdate": "Render 節點更新（GitHub 上傳覆蓋）",
      "n.renderTip1": "更新節點不需要 SSH/終端機：把更新檔（nodeweb 等）上傳到 GitHub repo（tacm-node 根目錄）覆蓋舊檔，Render autoDeploy 自動重建部署。",
      "n.renderTip2": "渲染節點（Render）網頁上傳：GitHub → repo 根目錄 → Upload files → 覆蓋後 Commit → Render 自動偵測變更重建。",
      "n.join1": "下載節點套件並在伺服器上解壓。",
      "n.join2": "使用對等種子清單啟動（無單一錨點）：",
      "n.join3": "觀察此面板——節點會自動同步並開始驗證區塊。",
      "n.join4": "每塊由在線節點均分 45% 節點獎勵，可由節點金鑰提取。",
      "n.footLine": "節點控制台",
      "n.online": "在線",
      "n.offline": "離線",
      "n.you": "本機"
    },
    en: {
      "n.brandSub": "Node Console",
      "n.synced": "Synced",
      "n.syncing": "Syncing",
      "n.behind": "{n} blocks behind",
      "n.openMainnet": "Open Mainnet",
      "n.deployerBtn": "Deployer Panel",
      "n.heroDeployer": "Open Deployer Panel",
      "n.heroJoin": "How to Join",
      "n.capTitle": "Network Capabilities",
      "n.capGov": "Parametrized Governance",
      "n.capDeFi": "DeFi Lending",
      "n.capAlert": "Webhook Alerts",
      "n.capBridge": "Bridge Kill-switch",
      "n.heroEyebrow": "TACm Chain · Mainnet",
      "n.heroTitle": "Node<br>Console",
      "n.heroDesc": "Run a TAC node, secure the network, validate blocks and split the 45% node reward among online nodes — all from your own branded node dashboard.",
      "n.cTip": "Chain Tip",
      "n.cTipSub": "Latest block height",
      "n.cFinal": "Finalized",
      "n.cFinalSub": "BFT finalized height",
      "n.cDiff": "Difficulty",
      "n.cDiffSub": "Dynamic PoT difficulty",
      "n.cSync": "Sync Progress",
      "n.cSyncSub": "Blocks behind best peer",
      "n.pNode": "Node Identity",
      "n.kAddress": "Node Address",
      "n.kNodeId": "Node ID",
      "n.kIdentity": "Identity Key",
      "n.kUptime": "Uptime",
      "n.kBaseFee": "Base Fee",
      "n.kConsensus": "Consensus",
      "n.kReward": "Node Reward",
      "n.rewardDesc": "Every block mints 10 TACM: 45% split among online PoT nodes, 15% to the reward pool, 40% split among online miners by hashrate.",
      "n.pPeers": "P2P Peers",
      "n.tNode": "Node",
      "n.tHeight": "Height",
      "n.tFinal": "Finalized",
      "n.tState": "State",
      "n.tCipher": "Cipher",
      "n.plain": "plain",
      "n.cipherOn": "encrypted",
      "n.pValidators": "Nodes",
      "n.tAddress": "Address",
      "n.tPower": "Power",
      "n.pBlocks": "Latest Blocks",
      "n.tProposer": "Proposer",
      "n.tTx": "Txs",
      "n.tDiff": "Diff",
      "n.pJoin": "Run Your Own Node",
      "n.oneClick": "One-Click Install (all platforms)", "n.oneClickTip": "Auto-detects systemd / nohup / Render, installs Go, builds, starts and prints your console URL.", "n.rawTip": "After pushing, the node binary gets a permanent raw link — no more expiring short links.",
      "n.github": "Source Code Permanent (GitHub)",
      "n.renderUpdate": "Update Node via Render (GitHub upload)",
      "n.renderTip1": "No SSH/terminal needed: upload the updated files (nodeweb etc.) to the GitHub repo root (tacm-node), overwriting the old ones; Render autoDeploy rebuilds automatically.",
      "n.renderTip2": "Render web upload: GitHub → repo root → Upload files → overwrite → Commit → Render detects the change and rebuilds.",
      "n.join1": "Download the node package and unpack it on your server.",
      "n.join2": "Start with the peer seed list (no single anchor):",
      "n.join3": "Watch this dashboard — your node will sync automatically and start validating blocks.",
      "n.join4": "Online nodes split the 45% node reward per block, withdrawable by the node key.",
      "n.footLine": "Node Console",
      "n.online": "online",
      "n.offline": "offline",
      "n.you": "self"
    }
  };
  var cur = localStorage.getItem("tac_lang") || "en";
  if (cur !== "zh") cur = "en";

  function apply() {
    document.documentElement.lang = cur;
    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      var key = el.getAttribute("data-i18n");
      var t = dict[cur][key];
      if (t === undefined) return;
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
        el.placeholder = t;
      } else {
        el.innerHTML = t;
      }
    });
    document.getElementById("langToggle").textContent = cur === "zh" ? "English" : "中文";
  }

  function t(key, sub) {
    var s = dict[cur][key] || key;
    if (sub) Object.keys(sub).forEach(function (k) { s = s.replace("{" + k + "}", sub[k]); });
    return s;
  }

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function short(s, n) {
    if (!s) return "—";
    n = n || 12;
    return s.length > n * 2 + 3 ? s.slice(0, n) + "…" + s.slice(-n) : s;
  }
  function ts(sec) {
    if (!sec) return "—";
    var d = new Date(sec * 1000);
    return d.toISOString().replace("T", " ").slice(0, 19);
  }

  var state = { mainnetURL: "" };

  function renderStatus(st) {
    $("tip").textContent = st.block_height;
    $("final").textContent = st.final_block_height;
    $("diff").textContent = st.effective_difficulty;
    $("behind").textContent = st.synced ? "0" : st.behind_blocks;
    $("nodeAddr").textContent = st.address;
    $("nodeId").textContent = short(st.node_id, 16);
    $("identity").textContent = short(st.identity_pub_hex, 14);
    $("uptime").textContent = st.uptime;
    $("baseFee").textContent = st.base_fee;
    $("consensus").textContent = st.consensus;
    state.mainnetURL = st.mainnet_url;
    var links = document.querySelectorAll("#mainnetLink, #footMainnet");
    links.forEach(function (a) { a.href = st.mainnet_url; });
    var pill = $("syncPill");
    if (st.synced) {
      pill.className = "pill pill-ok";
      pill.textContent = t("n.synced");
    } else {
      pill.className = "pill pill-warn";
      pill.textContent = t("n.syncing") + " · " + t("n.behind", { n: st.behind_blocks });
    }
  }

  function renderPeers(peers) {
    var on = peers.filter(function (p) { return p.online; }).length;
    $("peerCount").textContent = on;
    var tb = document.querySelector("#peerTbl tbody");
    tb.innerHTML = "";
    if (!peers.length) {
      var tr = document.createElement("tr");
      tr.innerHTML = '<td colspan="4" style="color:var(--muted)">—</td>';
      tb.appendChild(tr);
      return;
    }
    peers.forEach(function (p) {
      var tr = document.createElement("tr");
      var mark = p.online ? '<span class="dot-on">●</span>' : '<span class="dot-off">●</span>';
      tr.innerHTML =
        "<td>" + short(p.node_id, 10) + (p.owner === "self" ? " · " + esc(t("n.you")) : "") + "</td>" +
        "<td>" + p.height + "</td>" +
        "<td>" + (p.finalized_height ?? p.finalized ?? 0) + "</td>" +
        "<td>" + mark + " " + esc(p.online ? t("n.online") : t("n.offline")) + "</td>" +
        "<td>" + (p.encrypted === false ? "<span style=color:#d97706>⚠ " + esc(t("n.plain")) + "</span>" : "<span style=color:#16a34a>🔒 " + esc(t("n.cipherOn")) + "</span>") + "</td>";
      tb.appendChild(tr);
    });
  }

  function renderValidators(v) {
    $("valCount").textContent = v.total + " · Σ" + v.power + " · quorum " + v.quorum;
    var tb = document.querySelector("#valTbl tbody");
    tb.innerHTML = "";
    v.validators.forEach(function (val) {
      var tr = document.createElement("tr");
      tr.innerHTML = "<td>" + esc(val.address) + "</td><td>" + val.power + "</td>";
      tb.appendChild(tr);
    });
  }

  function renderBlocks(b) {
    var tb = document.querySelector("#blockTbl tbody");
    tb.innerHTML = "";
    if (!b.blocks.length) {
      var tr = document.createElement("tr");
      tr.innerHTML = '<td colspan="4" style="color:var(--muted)">—</td>';
      tb.appendChild(tr);
      return;
    }
    b.blocks.forEach(function (blk) {
      var tr = document.createElement("tr");
      tr.innerHTML =
        "<td>#" + blk.height + "</td>" +
        "<td>" + short(blk.proposer, 10) + "</td>" +
        "<td>" + blk.tx_count + "</td>" +
        "<td>" + blk.difficulty + "</td>";
      tb.appendChild(tr);
    });
  }

  function poll() {
    fetch("/api/status", { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("status"); return r.json(); })
      .then(renderStatus)
      .catch(function () { $("syncPill").className = "pill pill-err"; $("syncPill").textContent = "error"; });
    fetch("/api/peers", { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("peers"); return r.json(); })
      .then(function (d) { renderPeers(d.peers || []); })
      .catch(function () {});
    fetch("/api/validators", { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("validators"); return r.json(); })
      .then(renderValidators)
      .catch(function () {});
    fetch("/api/blocks", { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("blocks"); return r.json(); })
      .then(renderBlocks)
      .catch(function () {});
  }

  document.getElementById("langToggle").addEventListener("click", function () {
    cur = cur === "zh" ? "en" : "zh";
    localStorage.setItem("tac_lang", cur);
    apply();
    poll();
  });

  apply();
  poll();
  setInterval(poll, 10000);
})();
