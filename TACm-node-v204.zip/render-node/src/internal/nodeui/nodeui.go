// Package nodeui 提供節點獨立品牌前端（M86）：節點運維者專用儀表板——
// 鏈狀態 / 同步進度 / P2P peers / 驗證人集 / 出塊記錄 / 節點金鑰與獎勵。
// 與主網 tacweb（landing/錢包/交易所等用戶功能）完全分離：獨立 binary
// (cmd/nodeweb)、獨立資料夾 (internal/nodeui)、獨立品牌「TACm Chain — Node」。
package nodeui

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"encoding/json"
	"io/fs"
	"log"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"tacm/internal/config"
	"tacm/internal/node"
	"tacm/internal/p2p"
)

//go:embed templates static
var assets embed.FS

// nodeUIDownloadsDir v71：下載中心目錄。cmd/nodeweb 啟動時以 TACM_DOWNLOADS_DIR
// 指向 dataDir/downloads；未設定時預設 /var/tac/downloads（Render 部署用）。
func nodeUIDownloadsDir() string {
	if d := os.Getenv("TACM_DOWNLOADS_DIR"); d != "" {
		return d
	}
	return "/var/tac/downloads"
}

// seedNodeUIDownloads v71：啟動時將內嵌一鍵安裝腳本同步到 downloads 目錄，
// 保證任何節點的下載中心都提供最新 install-node.sh（Render 另有 Dockerfile COPY nodeweb）。
func seedNodeUIDownloads() {
	dir := nodeUIDownloadsDir()
	sub, err := fs.Sub(assets, "static/downloads")
	if err != nil {
		return
	}
	entries, err := fs.ReadDir(sub, ".")
	if err != nil {
		return
	}
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		data, derr := fs.ReadFile(sub, e.Name())
		if derr != nil {
			continue
		}
		_ = os.WriteFile(dir+"/"+e.Name(), data, 0o755)
	}
}

// Server 為節點品牌 UI 的 HTTP 服務器；直接持 *node.Node（本機視角），
// 不走主網 DataSource 介面——節點儀表讀取的是節點自身鏈/網/共識狀態。
type Server struct {
	n          *node.Node
	rpc        *node.RPCServer // v136：只讀 trace/debug 面（trace_filter 等放行）
	mainnetURL string
	nodeID     string
	started    time.Time
	mux        *http.ServeMux
	hub        *wsHub
	stopCh     chan struct{}
}

// New 建立節點 UI 服務器。mainnetURL 為開放挖礦/主網入口（預設創世節點）。
func New(n *node.Node, mainnetURL, nodeID string) *Server {
	if mainnetURL == "" {
		mainnetURL = config.PrimarySeed()
	}
	if nodeID == "" {
		nodeID = "node"
	}
	s := &Server{n: n, rpc: node.NewRPCServer(n), mainnetURL: strings.TrimRight(mainnetURL, "/"), nodeID: nodeID, started: time.Now(), hub: newWSHub()}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"status":"ok"}`))
	})
	// v53-B1：節點端只讀 eth JSON-RPC（查詢面與主鏈同級，寫入仍走主鏈）。
	mux.HandleFunc("POST /eth", s.handleEthReadonly)
	mux.HandleFunc("POST /eth/", s.handleEthReadonly)
	// v53-C5：節點端 WebSocket eth_subscribe（newHeads/newPendingTransactions）。
	mux.HandleFunc("GET /ws", s.handleWS)
	// 根路由精確匹配（GET /{$}）：避免與 P2P 全方法 /p2p/ 在 Go 1.22 ServeMux 衝突。
	mux.HandleFunc("GET /{$}", s.handleIndex)
	mux.HandleFunc("GET /api/status", s.handleStatus)
	mux.HandleFunc("GET /api/peers", s.handlePeers)
	mux.HandleFunc("GET /api/validators", s.handleValidators)
	mux.HandleFunc("GET /api/blocks", s.handleBlocks)
	// P0 快速狀態同步（snap/warp）：Render 部署用 nodeweb，種子節點必須提供狀態快照導出，
	// 新節點經 -snapshot-url 下載後秒級落點，無需自創世逐塊重放。與 tacweb（internal/web）
	// 的 /api/snapshot 協議一致（含 X-Snapshot-SHA256 校驗頭）。
	mux.HandleFunc("GET /api/snapshot", s.handleSnapshot)
	mux.HandleFunc("GET /api/snapshot/info", s.handleSnapshotInfo)
	// M148：節點架設者面板（綁定收款地址／節點獎勵查詢／提領轉入 tac web3 錢包）。
	mux.HandleFunc("GET /node-panel", s.handleNodePanel)
	mux.HandleFunc("GET /api/node/panel", s.handleNodePanelAPI)
	mux.HandleFunc("POST /api/node/setup", s.handleNodeSetupAPI)
	mux.HandleFunc("POST /api/node/bind", s.handleNodeBindAPI)
	mux.HandleFunc("POST /api/node/withdraw", s.handleNodeWithdrawAPI)
	mux.HandleFunc("POST /api/node/stake", s.handleNodeStakeAPI)         // M149m 質押成為驗證人
	mux.HandleFunc("POST /api/node/bootstrap", s.handleNodeBootstrapAPI) // M149m-2 節點引導獎勵
	mux.HandleFunc("POST /api/node/register", s.handleNodeRegisterAPI)   // M149m-9 PoT 節點註冊
	mux.Handle("GET /static/", http.StripPrefix("/static/", http.FileServer(http.FS(mustSub(assets, "static")))))
	// v71：下載中心——Render/任何節點都可提供 nodeweb/install-node.sh（繞過主鏈外部 502）。
	// v71：下載中心——Render/任何節點都可提供 nodeweb/install-node.sh（繞過主鏈外部 502）。
	_ = os.MkdirAll(nodeUIDownloadsDir(), 0o755)
	seedNodeUIDownloads()
	mux.Handle("GET /downloads/", http.StripPrefix("/downloads/", http.FileServer(http.Dir(nodeUIDownloadsDir()))))
	s.mux = mux
	// v53-C5：啟動 WS 推送循環（新區塊/交易池變化輪詢廣播）。
	go s.wsPump(s.stopCh)
	return s
}

// Mux 回傳原始 ServeMux（供 cmd/nodeweb 同埠合併 P2P 路由）。
func (s *Server) Mux() *http.ServeMux { return s.mux }

// Handler 回傳可掛載/監聽的 HTTP Handler（含 panic 防護：v53-A5 任一 request
// panic 回 500 而非讓整個節點程序崩潰）。
func (s *Server) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if rec := recover(); rec != nil {
				log.Printf("[nodeui] panic recovered: %v (path=%s)", rec, r.URL.Path)
				http.Error(w, "internal error", http.StatusInternalServerError)
			}
		}()
		s.mux.ServeHTTP(w, r)
	})
}

// ListenAndServe 在指定 addr 上提供節點 UI。
func (s *Server) ListenAndServe(addr string) error {
	log.Printf("[nodeui] TACm Chain — Node UI listening on %s", addr)
	return http.ListenAndServe(addr, s.mux)
}

func mustSub(fsys fs.FS, dir string) fs.FS {
	sub, err := fs.Sub(fsys, dir)
	if err != nil {
		panic(err)
	}
	return sub
}

// handleIndex 回傳節點品牌首頁。
func (s *Server) handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	raw, err := assets.ReadFile("templates/index.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	// 永不緩存 HTML：節點 UI 每次更新後手機直接取最新版（沿用 M84 原則）。
	w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate")
	_, _ = w.Write(raw)
}

type statusPayload struct {
	node.Status
	NodeID       string `json:"node_id"`
	Address      string `json:"address"`
	IdentityKey  string `json:"identity_pub_hex"`
	Synced       bool   `json:"synced"`
	PeersTotal   int    `json:"peers_total"`
	BestPeerH    int64  `json:"best_peer_height"`
	BehindBlocks int64  `json:"behind_blocks"`
	Uptime       string `json:"uptime"`
	MainnetURL   string `json:"mainnet_url"`
}

func (s *Server) handleStatus(w http.ResponseWriter, r *http.Request) {
	st := s.n.GetStatus()
	bestH := st.BlockHeight
	online := 0
	if pn := s.n.P2PNet(); pn != nil {
		for _, p := range pn.PeerSnapshot() {
			if p.Online && p.Height > bestH {
				bestH = p.Height
			}
			if p.Online {
				online++
			}
		}
	}
	behind := bestH - st.BlockHeight
	if behind < 0 {
		behind = 0
	}
	writeJSON(w, statusPayload{
		Status:       st,
		NodeID:       st.NodeID,
		Address:      s.n.Address(),
		IdentityKey:  s.n.IdentityPubHex(),
		Synced:       behind == 0,
		PeersTotal:   online,
		BestPeerH:    bestH,
		BehindBlocks: behind,
		Uptime:       time.Since(s.started).Round(time.Second).String(),
		MainnetURL:   s.mainnetURL,
	})
}

func (s *Server) handlePeers(w http.ResponseWriter, r *http.Request) {
	var peers []p2p.Peer
	if pn := s.n.P2PNet(); pn != nil {
		peers = pn.DisplayPeers()
	}
	writeJSON(w, map[string]any{"peers": peers})
}

func (s *Server) handleValidators(w http.ResponseWriter, r *http.Request) {
	vs := s.n.ValidatorSet()
	resp := map[string]any{
		"validators": vs.List(),
		"total":      vs.Len(),
		"power":      vs.TotalPower(),
		"quorum":     vs.QuorumPower(),
		"fault":      vs.FaultTolerance(),
		"dynamic":    false,
	}
	// M87：PoS 動態驗證人集（質押驅動，jailed 標記）。
	if ps := s.n.GetPosStore(); ps != nil {
		if vals, err := ps.GetActiveValidatorsForConsensus(21); err == nil && len(vals) > 0 {
			dyn := make([]map[string]any, 0, len(vals))
			for i := range vals {
				v := &vals[i]
				dyn = append(dyn, map[string]any{
					"address": v.Address, "name": v.Name, "stake": v.TotalStake,
					"power":  int(v.TotalStake/100) + 1,
					"status": v.Status, "jailed": v.Status == "jailed",
					"uptime": v.Uptime, "proposed": v.BlocksProposed, "missed": v.BlocksMissed,
				})
			}
			resp["dynamic"] = true
			resp["validators"] = dyn
			resp["total"] = len(dyn)
		}
	}
	writeJSON(w, resp)
}

// handleBlocks 回傳最近 N 塊（含 coinbase 獎勵結構摘要）。
func (s *Server) handleBlocks(w http.ResponseWriter, r *http.Request) {
	count := 10
	if v := r.URL.Query().Get("n"); v != "" {
		if c, err := strconv.Atoi(v); err == nil && c > 0 && c <= 30 {
			count = c
		}
	}
	tip := s.n.GetStatus().BlockHeight
	out := make([]map[string]any, 0, count)
	for h := tip; h >= 0 && len(out) < count; h-- {
		d, err := s.n.GetBlockDetail(h)
		if err != nil || d == nil {
			break
		}
		b := d.Block
		out = append(out, map[string]any{
			"height":           b.Height,
			"hash":             b.Hash,
			"proposer":         b.Proposer,
			"proposer_address": b.ProposerAddress,
			"ts":               b.Ts,
			"tx_count":         b.TxCount,
			"difficulty":       b.Difficulty,
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i]["height"].(int64) < out[j]["height"].(int64) })
	writeJSON(w, map[string]any{"blocks": out, "tip": tip})
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	if err := json.NewEncoder(w).Encode(v); err != nil {
		log.Printf("[nodeui] encode: %v", err)
	}
}

// handleSnapshotInfo GET /api/snapshot/info — 快照元資訊（輕量，不帶帳戶資料）。
// 與 internal/web 的同名端點欄位一致，便於 join 頁/部署腳本在兩種 binary 上通用。
func (s *Server) handleSnapshotInfo(w http.ResponseWriter, r *http.Request) {
	sd, err := s.n.ExportSnapshot()
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
		return
	}
	writeJSON(w, map[string]any{
		"ok":           true,
		"version":      sd.Version,
		"height":       sd.Height,
		"genesis_hash": sd.GenesisHash,
		"tip_hash":     sd.TipHash,
	})
}

// handleSnapshot GET /api/snapshot — 導出狀態快照（供新節點 -snapshot-url 導入）。
// 回應帶 X-Snapshot-SHA256，導入端下載後重算比對，防傳輸損壞/竄改；與 tacweb 端點協議一致。
func (s *Server) handleSnapshot(w http.ResponseWriter, r *http.Request) {
	sd, err := s.n.ExportSnapshot()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	raw, err := json.Marshal(sd)
	if err != nil {
		http.Error(w, "snapshot: marshal 失敗", http.StatusInternalServerError)
		return
	}
	sum := sha256.Sum256(raw)
	w.Header().Set("X-Snapshot-SHA256", hex.EncodeToString(sum[:]))
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	if _, err := w.Write(raw); err != nil {
		log.Printf("[nodeui] snapshot write: %v", err)
	}
}
