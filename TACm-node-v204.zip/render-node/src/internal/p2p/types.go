// Package p2p 實現 TACm 智能鏈的多節點網絡層：節點握手與自動發現、
// 區塊/交易 gossip 廣播、落後節點主動同步與鏈重組。傳輸採用 HTTP/JSON，
// 以 goroutine、context 與顯式 error 實現，並發安全。
package p2p

import (
	"time"

	"tacm/internal/bridge"
	"tacm/internal/chaindb"
	"tacm/internal/consensus/bft"
)

// ProtocolVersion 為 P2P 協議版本，握手不一致則拒絕對接。
const ProtocolVersion = 1

// Peer 為一個已連接的對等節點。
type Peer struct {
	NodeID    string `json:"node_id"`
	BaseURL   string `json:"base_url"`
	Owner     string `json:"owner"`
	Height    int64  `json:"height"`
	Finalized int64  `json:"finalized_height"`
	Online    bool   `json:"online"`
	// Encrypted 表示與該節點的 P2P 訊息通道是否加密（ECDH+AES-GCM）；
	// 對端不支援加密時自動降級明文並於此標記，供節點 UI 可視化。
	Encrypted bool      `json:"encrypted"`
	LastSeen  time.Time `json:"last_seen"`
	failCount int
}

// Config 為 P2P 網絡配置。
type Config struct {
	SelfID            string
	SelfURL           string // 本節點對外可達的基址（如 http://127.0.0.1:8333）
	Owner             string
	Bootstrap         []string // 初始引導節點基址（全部用於連線）
	// TrustedAnchor 為唯一受信任、可對已建立鏈歷史做整鏈覆蓋的主錨點基址。
	// 其餘引導/發現節點僅供同步與八卦，不同源時無權整鏈替換，避免分叉鏈互相覆蓋。
	TrustedAnchor     string
	HeartbeatInterval time.Duration
	SyncInterval      time.Duration
	DialTimeout       time.Duration
	// RequestTimeout 單次 HTTP 請求整體上限（含大 JSON 下載）。
	// 與 DialTimeout 分離：撥號快速失敗（2s），大範圍區塊拉取給足時間（預設 60s）。
	RequestTimeout time.Duration
	MaxPeers       int
	// Encrypt 啟用 P2P 訊息層加密（secp256k1 ECDH + AES-256-GCM）。
	// 預設開啟（v65 起節點預設加密）：/p2p/hello 與 /p2p/gossip 的 body
	// 均加密傳輸；對端不支援加密（舊版節點）時該通道自動降級明文並於
	// Peer.Encrypted 標記，全網不需同步開啟即可混跑。
	Encrypt bool
}

// Host 抽象 P2P 所需的節點能力，由節點層實現（適配），避免網絡層與節點強耦合。
type Host interface {
	// Height 返回本節點當前鏈頂高度。
	Height() int64
	// EmptyChain 回報本機是否無任何區塊（空庫 follower）；僅空庫節點允許整鏈替換。
	EmptyChain() bool
	// FinalizedHeight 返回已最終化高度。
	FinalizedHeight() int64
	// OnIncomingBlock 驗證並嘗試接入一個網絡傳來的區塊（含其交易）。
	OnIncomingBlock(block *chaindb.Block, txs []chaindb.Transaction) error
	// OnIncomingTx 驗證並接收一個網絡傳來的交易（進入內存池/賬本）。
	OnIncomingTx(tx map[string]any) error
	// OnIncomingVote 驗證並接收一個網絡傳來的共識投票（prevote/precommit）。
	OnIncomingVote(vote *bft.Vote) error
	// OnIncomingViewChange 接收一個 view-change（M12：帶驗證人與簽名，多數認證後切換輪次）。
	OnIncomingViewChange(height int64, round int32, validator, signature string) error
	// OnIncomingBridge 接收一個跨鏈橋網絡消息（提案/守衛簽名/執行結果）。
	OnIncomingBridge(bg *BridgeGossip) error
	// BlockDetail 返回指定高度區塊及其交易（同步拉取用）；不存在返回 (nil,nil,nil)。
	BlockDetail(height int64) (*chaindb.Block, []chaindb.Transaction, error)
	// ReorgChain 在共同分叉點 forkPoint 之後切換到 blocks 給定的新鏈：
	// 截斷本地 forkPoint 之後數據並順序重放；節點僅在新鏈累積難度更高時接受。
	ReorgChain(forkPoint int64, blocks []chaindb.Block, txs [][]chaindb.Transaction) error
	// ReorgChainFull 以整條新鏈做一次性總權重決策後切換（長鏈領先時取代分段重組）。
	ReorgChainFull(forkPoint int64, blocks []chaindb.Block, txs [][]chaindb.Transaction) error
	// ReorgChainTieBreak 用於同高度（等長）分叉的確定性收斂：僅當新鏈 tip 哈希
	// 字典序更小時才切換，全網各節點獨立計算皆得到同一 winner（無節點特權）。
	ReorgChainTieBreak(forkPoint int64, blocks []chaindb.Block, txs [][]chaindb.Transaction) error
}

// BridgeGossip 為跨鏈橋網絡消息：提案（propose）/守衛簽名（sig）/執行結果（exec）。
type BridgeGossip struct {
	Type         string                    `json:"type"`
	MessageID    string                    `json:"message_id"`
	Message      *bridge.CrossChainMessage `json:"message,omitempty"`
	Sig          *bridge.ValidatorSig      `json:"sig,omitempty"`
	BridgeTxID   string                    `json:"bridge_tx_id,omitempty"`
	TargetTxHash string                    `json:"target_tx_hash,omitempty"`
}
