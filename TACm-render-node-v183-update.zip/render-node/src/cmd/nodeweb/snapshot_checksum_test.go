package main

// snapshot_checksum_test.go — v68：快照 SHA256 校驗測試。
// 相符→通過；被竄改→拒絕；舊快照源（無 checksum）→相容跳過。

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
	"testing"
)

func TestVerifySnapshotChecksumMatch(t *testing.T) {
	body := []byte(`{"height":100,"genesis_hash":"abc"}`)
	sum := sha256.Sum256(body)
	want := hex.EncodeToString(sum[:])
	if err := verifySnapshotChecksum(body, want); err != nil {
		t.Fatalf("相符校驗應通過: %v", err)
	}
}

func TestVerifySnapshotChecksumMismatch(t *testing.T) {
	body := []byte(`{"height":100,"genesis_hash":"abc"}`)
	// 竄改 body（高度改 999）→ 校驗應失敗。
	tampered := []byte(`{"height":999,"genesis_hash":"abc"}`)
	sum := sha256.Sum256(body)
	want := hex.EncodeToString(sum[:])
	err := verifySnapshotChecksum(tampered, want)
	if err == nil {
		t.Fatal("竄改快照應被拒絕")
	}
	if !strings.Contains(err.Error(), "校驗和不符") {
		t.Fatalf("錯誤訊息應說明校驗和不符: %v", err)
	}
}

func TestVerifySnapshotChecksumCompatNoHeader(t *testing.T) {
	// 舊快照源無 X-Snapshot-SHA256 header → 相容跳過（不阻擋導入）。
	body := []byte(`{"height":100}`)
	if err := verifySnapshotChecksum(body, ""); err != nil {
		t.Fatalf("無 checksum 應相容跳過: %v", err)
	}
}
